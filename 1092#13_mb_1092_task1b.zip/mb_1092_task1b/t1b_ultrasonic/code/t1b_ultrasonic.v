/*
Module HC_SR04 Ultrasonic Sensor

This module will detect objects present in front of the range, and give the distance in mm.

Input:  clk_50M - 50 MHz clock
        reset   - reset input signal (Use negative reset)
        echo_rx - receive echo from the sensor

Output: trig    - trigger sensor for the sensor
        op     -  output signal to indicate object is present.
        distance_out - distance in mm, if object is present.
*/

// module Declaration
module t1b_ultrasonic(
    input clk_50M, reset, echo_rx,
    output reg trig,
    output op,
    output wire [15:0] distance_out
);
reg [1:0]state;
reg [19:0]count;
reg [15:0] dist;


initial begin	
    trig = 0;

end
//////////////////DO NOT MAKE ANY CHANGES ABOVE THIS LINE //////////////////

//reg trigcount [3:0] <= 4'b0000;

initial begin	
    state = 2'b00;
	 count = 0;
	 dist = 0;
	 

end

assign distance_out = dist;
assign op = (dist>=70)? 1'b0:1'b1 ;


always @(posedge clk_50M)begin
   if(~reset) begin
	count<=0;
	state<=2'b00;
	trig <=0;
	end
	
	
	case(state)
	2'b00: 	begin
	            if(count<50)
						count <= count+1'b1;
					else 
						begin
							count<=0;
							state<=2'b01;
						end
				end
				
	2'b01:   begin
				trig<=1;
				if (count<500)
					count <= count+1'b1;
				else
					begin
					count<=0;
					state <=2'b10;
					trig <= 0;
					end
				end
	
	2'b10:  begin
			  if(echo_rx & 1)
			  count<=count+1'b1;
			  else
				   begin
					state<=2'b11;
					dist<= count*34/10000;
					end
			  end
			  
	2'b11:  begin
	        if(count<600000)
			  count<=count+1'b1;
			  else
					begin
					count <= 0;
					state <= 2'b00;
					end
				end
	endcase

	end

//////////////////DO NOT MAKE ANY CHANGES BELOW THIS LINE //////////////////

endmodule
